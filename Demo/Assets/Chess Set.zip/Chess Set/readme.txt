Chess Set from Gentlemen Gaming
gentlemengaming.net

Prefabs for use in your game are in the prefabs folder.  

Theres a simple demo scene included as well.  



